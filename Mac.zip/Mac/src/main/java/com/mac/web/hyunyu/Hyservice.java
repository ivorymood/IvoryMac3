package com.mac.web.hyunyu;

import org.springframework.stereotype.Component;

@Component 
public interface Hyservice {
//
}
