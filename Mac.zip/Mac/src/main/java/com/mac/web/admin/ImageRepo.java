package com.mac.web.admin;

public enum ImageRepo {
	UPLOAD_PATH{
		@Override
		public String toString() {
			return "C:\\Users\\1027\\Downloads\\IvoryMac3-HyunYu (1)\\IvoryMac3-HyunYu\\Mac\\src\\main\\webapp\\resources\\img\\";
		}
	}
}
