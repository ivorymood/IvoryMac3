package com.mac.web.service;

import java.util.HashMap;

public interface IUpdateService {
	public void execute(HashMap<?, ?> param);
}
