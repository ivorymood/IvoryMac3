package com.mac.web.service;

import java.util.HashMap;

public interface IDeleteService {
	public void execute(HashMap<?, ?> param);
}
